package com.example.SpringInitializrProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInitializrProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInitializrProjectApplication.class, args);
	}

}
