package com.example.SpringInitializrProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInitializrProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
